var lista = document.getElementById('lista');
var elenco = [];
window.addEventListener('DOMContentLoaded', init);

function init() {
    stampaDati();
}

function stampaDati() {
    
    fetch('https://jsonplaceholder.typicode.com/users').then((response) => {
        return response.json();
    }).then((data) => {
        
        elenco = data;
        lista.innerHTML = '';
        if (elenco.length > 0) {
        elenco.map(function(element) {
            let colonna1 = `<tr><td>${element.name}</td>`;
            let colonna2 = `<td>${element.username}</td>`;
            let colonna3 = `<td>${element.email}</td>`;
            let colonna4 = `<td>${element.phone}</td></tr>`;
        lista.innerHTML += `${colonna1}${colonna2}${colonna3}${colonna4}` 
        });
        }
    });
    
}
